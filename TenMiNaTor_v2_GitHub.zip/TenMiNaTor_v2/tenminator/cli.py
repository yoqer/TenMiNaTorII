"""
CLI de TenMiNaTor — Interfaz de línea de comandos.

Uso:
    tenminator quantize model.bin --bits 4 --output model-q4.gguf
    tenminator recommend --params 7 --vram 8
    tenminator info
    tenminator export model-q4.gguf --format unikernel --runtime unikraft
"""
import argparse
import sys
import json
import numpy as np


def cmd_info(args):
    """Muestra información de la librería."""
    from . import __version__
    from .quantization import Quantizer
    
    print(f"TenMiNaTor v{__version__}")
    print(f"Ecosistema: yoqer (TERMINATORI, TerminaTodo, TERMINATOR, TeMiNaTor)")
    print()
    print("Formatos de cuantización disponibles:")
    print(f"{'Formato':<14} {'Bits':>4}  {'Pérdida':<10} {'Velocidad':<8} {'Hardware'}")
    print("-" * 70)
    for name, info in Quantizer.list_formats().items():
        print(f"{name:<14} {info['bits']:>4}  {info['loss']:<10} {info['speed']:<8} {info['hw']}")


def cmd_recommend(args):
    """Recomienda formato de cuantización."""
    from .quantization import Quantizer
    
    result = Quantizer.recommend(args.params, args.vram)
    print(f"Modelo: {result['model_params_b']}B | VRAM: {result['vram_gb']} GB")
    print(f"{'Formato':<14} {'Bits':>4}  {'VRAM':>6}  {'Pérdida':<10} {'Velocidad':<8} {'Cabe':>5}")
    print("-" * 60)
    for r in result["formats"]:
        marker = " ★" if r["recommended"] else ""
        fits = "✓" if r["fits"] else "✗"
        print(f"{r['format']:<14} {r['bits']:>4}  {r['vram_needed_gb']:>5.1f}G  {r['loss']:<10} {r['speed']:<8} {fits:>5}{marker}")


def cmd_quantize(args):
    """Cuantiza un modelo."""
    from .quantization import Quantizer, QuantConfig
    from .quantization.export import GGUFExporter
    
    print(f"Cargando modelo: {args.input}")
    
    # Cargar pesos (soporta .npz, .npy, .pkl)
    if args.input.endswith(".npz"):
        data = np.load(args.input)
        state_dict = {k: data[k] for k in data.files}
    elif args.input.endswith(".npy"):
        weights = np.load(args.input)
        state_dict = {"weights": weights}
    elif args.input.endswith(".pkl"):
        import pickle
        with open(args.input, "rb") as f:
            state_dict = pickle.load(f)
    else:
        print(f"Formato no soportado: {args.input}")
        print("Formatos soportados: .npz, .npy, .pkl")
        sys.exit(1)
    
    method = args.method or "auto"
    config = QuantConfig(bits=args.bits, method=method, group_size=args.group_size)
    quantizer = Quantizer(config)
    
    print(f"Cuantizando a {args.bits}-bit ({method})...")
    result = quantizer.quantize_model(state_dict)
    stats = quantizer.stats
    
    print(f"  Capas: {stats['layers']}")
    print(f"  Original: {stats['original_mb']:.1f} MB")
    print(f"  Cuantizado: {stats['quantized_mb']:.1f} MB")
    print(f"  Compresión: {stats['compression_ratio']}x")
    
    # Exportar
    output = args.output or args.input.rsplit(".", 1)[0] + f"-q{args.bits}.gguf"
    
    if output.endswith(".gguf"):
        exporter = GGUFExporter(model_name=args.name or "tenminator-model")
        exporter.export(result, output)
        print(f"Exportado: {output}")
    else:
        import pickle
        with open(output, "wb") as f:
            pickle.dump(result, f)
        print(f"Guardado: {output}")


def cmd_export(args):
    """Exporta modelo cuantizado a formato de despliegue."""
    from .quantization.export import UnikernelExporter, ChipExporter
    
    print(f"Exportando {args.input} como {args.format}...")
    
    import pickle
    with open(args.input, "rb") as f:
        model = pickle.load(f)
    
    output_dir = args.output or "./deploy"
    
    if args.format == "unikernel":
        exporter = UnikernelExporter(runtime=args.runtime or "unikraft")
        exporter.export(model, output_dir, model_name=args.name or "model")
        print(f"Archivos de despliegue en: {output_dir}/")
    elif args.format == "chip":
        exporter = ChipExporter(target=args.target or "taalas_hc1")
        path = f"{output_dir}/{args.name or 'model'}.bin"
        exporter.export(model, path)
        print(f"Exportado para chip: {path}")
    else:
        print(f"Formato no soportado: {args.format}")


def main():
    parser = argparse.ArgumentParser(
        prog="tenminator",
        description="TenMiNaTor — Framework de Deep Learning con cuantización avanzada"
    )
    sub = parser.add_subparsers(dest="command")
    
    # info
    sub.add_parser("info", help="Información de la librería y formatos disponibles")
    
    # recommend
    p_rec = sub.add_parser("recommend", help="Recomendar formato de cuantización")
    p_rec.add_argument("--params", type=float, required=True, help="Parámetros del modelo en billones (B)")
    p_rec.add_argument("--vram", type=float, required=True, help="VRAM disponible en GB")
    
    # quantize
    p_q = sub.add_parser("quantize", help="Cuantizar un modelo")
    p_q.add_argument("input", help="Archivo de pesos (.npz, .npy, .pkl)")
    p_q.add_argument("--bits", type=int, default=4, choices=[1, 2, 3, 4, 5, 6, 8])
    p_q.add_argument("--method", default=None, help="Método: auto, turboquant, kivi, bitnet, nvfp4, ant4")
    p_q.add_argument("--group-size", type=int, default=32)
    p_q.add_argument("--output", "-o", default=None)
    p_q.add_argument("--name", default=None, help="Nombre del modelo")
    
    # export
    p_e = sub.add_parser("export", help="Exportar modelo cuantizado")
    p_e.add_argument("input", help="Modelo cuantizado (.pkl)")
    p_e.add_argument("--format", choices=["unikernel", "chip"], required=True)
    p_e.add_argument("--runtime", default="unikraft", help="Runtime: unikraft, nanovms, firecracker")
    p_e.add_argument("--target", default="taalas_hc1", help="Target chip: taalas_hc1, taalas_hc2")
    p_e.add_argument("--output", "-o", default=None)
    p_e.add_argument("--name", default=None)
    
    args = parser.parse_args()
    
    commands = {
        "info": cmd_info,
        "recommend": cmd_recommend,
        "quantize": cmd_quantize,
        "export": cmd_export,
    }
    
    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
