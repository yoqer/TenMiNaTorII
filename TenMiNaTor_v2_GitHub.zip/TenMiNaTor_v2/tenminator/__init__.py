"""
TenMiNaTor — Framework de Deep Learning ultraligero con cuantización avanzada.

Cuantización: Q8, Q6, Q5, Q4, Q3 (TurboQuant), Q2 (KIVI), Q1 (BitNet),
              NVFP4 (Blackwell), ANT4 (Adaptive Numerical Type)
Exportación:  GGUF, Chip (Taalas), Unikernel (NanoVMs/Unikraft/Firecracker)
Ecosistema:   TERMINATORI, TerminaTodo, TERMINATOR, TeMiNaTor

pip install tenminator
pip install tenminator[all]  # Con todas las dependencias opcionales
"""

__version__ = "2.0.0"
__author__ = "yoqer"

# Core
from .tensor import Tensor
from .nn import (
    Module, Parameter, Linear, Embedding, LayerNorm, RMSNorm,
    ReLU, GELU, SiLU, Dropout, Sequential,
    MultiHeadAttention, TransformerBlock,
    MSELoss, CrossEntropyLoss,
)
from .autograd import backward
from .optim import SGD, Adam, AdamW, CosineAnnealingLR
from .training import TrainingConfig, TrainingController
from .config import ModelConfig, FullConfig
from .backends import set_backend, get_backend

# Razonamiento y steering
from .reasoning import AbsoluteZeroReasoner, TaskProposer
from .steering import SteeringHook, BiasCorrector

# Cuantización
from .quantization import Quantizer, QuantConfig

# Integraciones
from .integrations import TerminatoriBridge, TerminaTodoBridge, UnslothBridge, LangChainRunnable

__all__ = [
    # Core
    "Tensor", "Module", "Parameter", "Linear", "Embedding", "LayerNorm", "RMSNorm",
    "ReLU", "GELU", "SiLU", "Dropout", "Sequential",
    "MultiHeadAttention", "TransformerBlock",
    "MSELoss", "CrossEntropyLoss",
    "backward", "SGD", "Adam", "AdamW", "CosineAnnealingLR",
    "TrainingConfig", "TrainingController",
    "ModelConfig", "FullConfig", "set_backend", "get_backend",
    "AbsoluteZeroReasoner", "SteeringHook", "BiasCorrector",
    # Cuantización
    "Quantizer", "QuantConfig",
    # Integraciones
    "TerminatoriBridge", "TerminaTodoBridge", "UnslothBridge", "LangChainRunnable",
]
