"""
Puentes de integración con el ecosistema yoqer:
- TERMINATORI (inferencia avanzada con skills/Aureolas)
- TerminaTodo (gestión de almacenamiento y sincronización)
- Unsloth (fine-tuning acelerado)
- LangChain (LCEL compatible)
"""
import json
import os
from typing import Dict, Any, Optional, List
import numpy as np


class TerminatoriBridge:
    """
    Conecta TenMiNaTor con TERMINATORI para inferencia avanzada.
    
    Uso:
        bridge = TerminatoriBridge("http://localhost:8001")
        response = bridge.chat("Hola, ¿qué puedes hacer?")
        bridge.load_model("model.gguf")
    """
    
    def __init__(self, api_url: str = "http://localhost:8001"):
        self.api_url = api_url.rstrip("/")
        self._session = None
    
    def _get_session(self):
        if self._session is None:
            try:
                import requests
                self._session = requests.Session()
            except ImportError:
                raise ImportError("pip install requests")
        return self._session
    
    def chat(self, message: str, model: str = "gemma4:e2b",
             skills: Optional[List[str]] = None) -> str:
        """Envía mensaje al chat de TERMINATORI."""
        s = self._get_session()
        payload = {"message": message, "model": model}
        if skills:
            payload["skills"] = skills
        r = s.post(f"{self.api_url}/api/v1/chat", json=payload, timeout=60)
        r.raise_for_status()
        return r.json().get("response", "")
    
    def load_model(self, model_path: str, format: str = "gguf") -> Dict:
        """Carga un modelo cuantizado en TERMINATORI."""
        s = self._get_session()
        r = s.post(f"{self.api_url}/api/v1/models/load",
                    json={"path": model_path, "format": format}, timeout=120)
        r.raise_for_status()
        return r.json()
    
    def list_skills(self) -> List[Dict]:
        """Lista las skills/Aureolas disponibles."""
        s = self._get_session()
        r = s.get(f"{self.api_url}/api/v1/skills", timeout=10)
        r.raise_for_status()
        return r.json().get("skills", [])
    
    def health(self) -> Dict:
        """Verifica el estado de TERMINATORI."""
        s = self._get_session()
        r = s.get(f"{self.api_url}/api/v1/health", timeout=5)
        r.raise_for_status()
        return r.json()


class TerminaTodoBridge:
    """
    Conecta TenMiNaTor con TerminaTodo para gestión de almacenamiento.
    
    Uso:
        bridge = TerminaTodoBridge("http://localhost:8002")
        bridge.upload_model("model.gguf", "/models/my-model.gguf")
        bridge.sync("local", "cloud")
    """
    
    def __init__(self, api_url: str = "http://localhost:8002"):
        self.api_url = api_url.rstrip("/")
        self._session = None
    
    def _get_session(self):
        if self._session is None:
            try:
                import requests
                self._session = requests.Session()
            except ImportError:
                raise ImportError("pip install requests")
        return self._session
    
    def upload_model(self, local_path: str, remote_path: str,
                     storage: str = "default") -> Dict:
        """Sube un modelo cuantizado al almacenamiento gestionado."""
        s = self._get_session()
        with open(local_path, "rb") as f:
            r = s.post(
                f"{self.api_url}/api/v1/files/upload",
                files={"file": (os.path.basename(local_path), f)},
                data={"path": remote_path, "storage": storage},
                timeout=300
            )
        r.raise_for_status()
        return r.json()
    
    def download_model(self, remote_path: str, local_path: str,
                       storage: str = "default") -> str:
        """Descarga un modelo desde el almacenamiento gestionado."""
        s = self._get_session()
        r = s.get(
            f"{self.api_url}/api/v1/files/download",
            params={"path": remote_path, "storage": storage},
            stream=True, timeout=300
        )
        r.raise_for_status()
        with open(local_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
        return local_path
    
    def sync(self, source: str = "local", target: str = "cloud") -> Dict:
        """Sincroniza almacenamiento entre fuentes."""
        s = self._get_session()
        r = s.post(
            f"{self.api_url}/api/v1/sync",
            json={"source": source, "target": target},
            timeout=60
        )
        r.raise_for_status()
        return r.json()
    
    def list_files(self, path: str = "/", storage: str = "default") -> List[Dict]:
        """Lista archivos en el almacenamiento."""
        s = self._get_session()
        r = s.get(
            f"{self.api_url}/api/v1/files",
            params={"path": path, "storage": storage},
            timeout=10
        )
        r.raise_for_status()
        return r.json().get("files", [])


class UnslothBridge:
    """
    Conecta TenMiNaTor con Unsloth para fine-tuning acelerado.
    
    Uso:
        bridge = UnslothBridge()
        bridge.finetune("unsloth/Qwen2.5-7B-bnb-4bit", dataset, output_dir="./output")
    """
    
    @staticmethod
    def to_unsloth_format(state_dict: Dict[str, np.ndarray]) -> Dict[str, Any]:
        """Convierte state_dict de TenMiNaTor al formato Unsloth/HuggingFace."""
        try:
            import torch
        except ImportError:
            raise ImportError("pip install torch (necesario para conversión a Unsloth)")
        
        hf_state = {}
        for name, weights in state_dict.items():
            hf_state[name] = torch.from_numpy(weights.astype(np.float32))
        return hf_state
    
    @staticmethod
    def from_unsloth_format(hf_state_dict: Dict) -> Dict[str, np.ndarray]:
        """Convierte state_dict de Unsloth/HuggingFace a TenMiNaTor."""
        result = {}
        for name, tensor in hf_state_dict.items():
            if hasattr(tensor, "numpy"):
                result[name] = tensor.detach().cpu().numpy()
            elif hasattr(tensor, "float"):
                result[name] = tensor.float().detach().cpu().numpy()
            else:
                result[name] = np.array(tensor)
        return result
    
    @staticmethod
    def finetune(model_name: str, dataset_path: str,
                 output_dir: str = "./output",
                 max_steps: int = 100,
                 lora_r: int = 16,
                 learning_rate: float = 2e-4) -> Dict[str, Any]:
        """
        Lanza fine-tuning con Unsloth (requiere unsloth instalado).
        Retorna las métricas del entrenamiento.
        """
        try:
            from unsloth import FastLanguageModel
            from trl import SFTTrainer
            from transformers import TrainingArguments
            import datasets
        except ImportError:
            return {
                "status": "not_available",
                "message": "Instala: pip install unsloth trl transformers datasets",
                "command": f"python -m unsloth.cli train --model {model_name} "
                           f"--dataset {dataset_path} --output {output_dir} "
                           f"--max_steps {max_steps} --lora_r {lora_r}"
            }
        
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=model_name,
            max_seq_length=2048,
            load_in_4bit=True,
        )
        
        model = FastLanguageModel.get_peft_model(
            model, r=lora_r, lora_alpha=lora_r * 2,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                            "gate_proj", "up_proj", "down_proj"],
        )
        
        dataset = datasets.load_dataset("json", data_files=dataset_path, split="train")
        
        trainer = SFTTrainer(
            model=model, tokenizer=tokenizer,
            train_dataset=dataset,
            args=TrainingArguments(
                output_dir=output_dir,
                max_steps=max_steps,
                learning_rate=learning_rate,
                per_device_train_batch_size=2,
                gradient_accumulation_steps=4,
                fp16=True,
                logging_steps=10,
                save_steps=max_steps,
            ),
        )
        
        result = trainer.train()
        model.save_pretrained(output_dir)
        
        return {
            "status": "completed",
            "output_dir": output_dir,
            "train_loss": result.training_loss,
            "steps": result.global_step,
        }


class LangChainRunnable:
    """
    Envuelve un modelo TenMiNaTor como Runnable de LangChain (LCEL).
    
    Uso:
        from langchain_core.runnables import RunnablePassthrough
        runnable = LangChainRunnable(model, tokenizer_fn)
        chain = {"input": RunnablePassthrough()} | runnable
        result = chain.invoke("Hola")
    """
    
    def __init__(self, model, tokenizer_fn: callable, max_len: int = 128):
        self.model = model
        self.tokenizer_fn = tokenizer_fn
        self.max_len = max_len
        if hasattr(model, "eval"):
            model.eval()
    
    def invoke(self, input_text: str, config: Optional[Dict] = None) -> str:
        tokens = self.tokenizer_fn(input_text)
        from ..tensor import Tensor
        input_tensor = Tensor(np.array([tokens]))
        
        if hasattr(self.model, "generate"):
            output = self.model.generate(input_tensor, max_len=self.max_len)
            return f"[TenMiNaTor] {output.data.tolist()}"
        else:
            logits = self.model(input_tensor)
            output_ids = np.argmax(logits.data, axis=-1)
            return f"[TenMiNaTor] {output_ids.tolist()}"
    
    def stream(self, input_text: str, config: Optional[Dict] = None):
        result = self.invoke(input_text, config)
        for word in result.split():
            yield word + " "
    
    def batch(self, inputs: List[str], config: Optional[Dict] = None) -> List[str]:
        return [self.invoke(text, config) for text in inputs]
