"""TenMiNaTor Steering — Vectores de dirección y corrección de sesgos."""
import numpy as np
from typing import List, Dict, Any
from .nn import Module


class SteeringHook:
    """Hook para aplicar steering a una capa específica."""
    
    def __init__(self, layer: Module, steering_vector: np.ndarray, strength: float):
        self.layer = layer
        self.steering_vector = steering_vector
        self.strength = strength

    def apply(self):
        """Aplica el steering a los pesos de la capa."""
        for name, param in self.layer.named_parameters().items():
            if "weight" in name:
                param.data += self.steering_vector * self.strength


class BiasCorrector:
    """Aplica corrección de sesgos a una capa durante la inferencia."""
    
    def __init__(self, layer: Module, correction_vector: np.ndarray, strength: float):
        self.layer = layer
        self.correction_vector = correction_vector
        self.strength = strength

    def __enter__(self):
        self.original_weights = {
            name: p.data.copy() for name, p in self.layer.named_parameters().items()
        }
        for name, param in self.layer.named_parameters().items():
            if "weight" in name:
                param.data += self.correction_vector * self.strength
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        for name, original_weight in self.original_weights.items():
            self.layer.named_parameters()[name].data = original_weight
