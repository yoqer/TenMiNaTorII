"""
Exportadores de modelos cuantizados a formatos de distribución:
- GGUF (llama.cpp / Ollama / LM Studio)
- Chip (Taalas HC1/HC2, ASIC)
- Unikernel (NanoVMs / Unikraft + Firecracker)
"""
import struct
import json
import os
import hashlib
from typing import Dict, Optional, Any
import numpy as np
from .formats import QuantizedTensor


class GGUFExporter:
    """
    Exporta modelo cuantizado al formato GGUF v3.
    Compatible con: llama.cpp, Ollama, LM Studio, GPT4All, koboldcpp.
    """
    
    GGUF_MAGIC = 0x46475547  # "GGUF"
    GGUF_VERSION = 3
    
    # Mapeo de formatos TenMiNaTor → tipos GGUF
    GGUF_TYPES = {
        "Q8_0": 8, "Q6_K": 14, "Q5_K_M": 13, "Q4_K_M": 15,
        "TQ3_0": 26, "Q2_KIVI": 10, "Q1_BitNet": 30,
        "NVFP4": 31, "ANT4": 32,
    }
    
    def __init__(self, model_name: str = "tenminator-model", architecture: str = "llama"):
        self.model_name = model_name
        self.architecture = architecture
        self.metadata: Dict[str, Any] = {}
    
    def export(self, quantized_model: Dict[str, QuantizedTensor], output_path: str,
               vocab_size: int = 32000, context_length: int = 4096) -> str:
        """
        Exporta modelo cuantizado a archivo GGUF.
        
        Retorna la ruta del archivo generado.
        """
        self.metadata = {
            "general.architecture": self.architecture,
            "general.name": self.model_name,
            "general.quantization_version": 2,
            "general.file_type": self._detect_file_type(quantized_model),
            f"{self.architecture}.vocab_size": vocab_size,
            f"{self.architecture}.context_length": context_length,
            "tenminator.version": "2.0.0",
            "tenminator.quantization_engine": "TenMiNaTor Quantizer",
        }
        
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
        
        with open(output_path, "wb") as f:
            # Header
            f.write(struct.pack("<I", self.GGUF_MAGIC))
            f.write(struct.pack("<I", self.GGUF_VERSION))
            f.write(struct.pack("<Q", len(quantized_model)))  # n_tensors
            f.write(struct.pack("<Q", len(self.metadata)))     # n_kv
            
            # Metadata KV pairs
            for key, value in self.metadata.items():
                self._write_string(f, key)
                if isinstance(value, int):
                    f.write(struct.pack("<I", 4))  # GGUF_TYPE_UINT32
                    f.write(struct.pack("<I", value))
                elif isinstance(value, str):
                    f.write(struct.pack("<I", 8))  # GGUF_TYPE_STRING
                    self._write_string(f, value)
                elif isinstance(value, float):
                    f.write(struct.pack("<I", 6))  # GGUF_TYPE_FLOAT32
                    f.write(struct.pack("<f", value))
            
            # Tensor info
            tensor_offsets = {}
            current_offset = 0
            for name, qt in quantized_model.items():
                self._write_string(f, name)
                n_dims = len(qt.shape)
                f.write(struct.pack("<I", n_dims))
                for dim in qt.shape:
                    f.write(struct.pack("<Q", dim))
                gguf_type = self.GGUF_TYPES.get(qt.format_name, 0)
                f.write(struct.pack("<I", gguf_type))
                f.write(struct.pack("<Q", current_offset))
                
                tensor_offsets[name] = current_offset
                data_size = qt.data.nbytes + qt.scales.nbytes
                if qt.zeros is not None:
                    data_size += qt.zeros.nbytes
                current_offset += data_size
            
            # Alignment padding
            alignment = 32
            pos = f.tell()
            pad = (alignment - pos % alignment) % alignment
            f.write(b"\x00" * pad)
            
            # Tensor data
            for name, qt in quantized_model.items():
                f.write(qt.scales.tobytes())
                if qt.zeros is not None:
                    f.write(qt.zeros.tobytes())
                f.write(qt.data.tobytes())
        
        return output_path
    
    def _write_string(self, f, s: str):
        encoded = s.encode("utf-8")
        f.write(struct.pack("<Q", len(encoded)))
        f.write(encoded)
    
    def _detect_file_type(self, model: Dict[str, QuantizedTensor]) -> int:
        formats = set(qt.format_name for qt in model.values())
        if "Q4_K_M" in formats:
            return 15
        if "TQ3_0" in formats:
            return 26
        if "Q1_BitNet" in formats:
            return 30
        return 0


class ChipExporter:
    """
    Exporta modelo cuantizado para chips dedicados (Taalas HC1/HC2, ASIC, FPGA).
    
    Formato: Binario compacto con pesos pre-organizados para acceso secuencial.
    Compatible con: Taalas HC1 (3-bit), HC2 (4-bit), FPGA custom.
    """
    
    CHIP_MAGIC = b"TMCH"  # TenMiNaTor CHip
    CHIP_VERSION = 1
    
    def __init__(self, target: str = "taalas_hc1"):
        """
        target: taalas_hc1, taalas_hc2, fpga_generic, asic_generic
        """
        self.target = target
        self.target_bits = {"taalas_hc1": 3, "taalas_hc2": 4, "fpga_generic": 4, "asic_generic": 8}
    
    def export(self, quantized_model: Dict[str, QuantizedTensor], output_path: str) -> str:
        """Exporta modelo en formato binario para chip."""
        target_bits = self.target_bits.get(self.target, 4)
        
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
        
        # Manifest JSON con metadatos
        manifest = {
            "format": "tenminator_chip_v1",
            "target": self.target,
            "target_bits": target_bits,
            "layers": {},
            "total_params": 0,
            "checksum": "",
        }
        
        all_data = bytearray()
        
        for name, qt in quantized_model.items():
            layer_offset = len(all_data)
            
            # Serializar escala + datos de forma compacta
            scale_bytes = qt.scales.astype(np.float16).tobytes()
            data_bytes = qt.data.tobytes()
            
            all_data.extend(scale_bytes)
            all_data.extend(data_bytes)
            
            n_params = int(np.prod(qt.shape))
            manifest["layers"][name] = {
                "offset": layer_offset,
                "scale_size": len(scale_bytes),
                "data_size": len(data_bytes),
                "shape": list(qt.shape),
                "bits": qt.bits,
                "format": qt.format_name,
                "params": n_params,
            }
            manifest["total_params"] += n_params
        
        manifest["checksum"] = hashlib.sha256(bytes(all_data)).hexdigest()
        
        with open(output_path, "wb") as f:
            f.write(self.CHIP_MAGIC)
            f.write(struct.pack("<H", self.CHIP_VERSION))
            
            manifest_json = json.dumps(manifest).encode("utf-8")
            f.write(struct.pack("<I", len(manifest_json)))
            f.write(manifest_json)
            f.write(bytes(all_data))
        
        # También guardar manifest legible
        manifest_path = output_path.replace(".bin", "_manifest.json")
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)
        
        return output_path
    
    def estimate_silicon_area(self, quantized_model: Dict[str, QuantizedTensor]) -> Dict[str, Any]:
        """Estima el área de silicio necesaria para grabar el modelo."""
        total_bits = sum(
            int(np.prod(qt.shape)) * qt.bits
            for qt in quantized_model.values()
        )
        total_transistors = total_bits * 6  # ~6 transistores por bit SRAM
        area_mm2 = total_transistors / 100e6  # ~100M transistores/mm² en 7nm
        
        return {
            "total_bits": total_bits,
            "total_bytes": total_bits // 8,
            "total_mb": total_bits / 8 / 1024 / 1024,
            "estimated_transistors": total_transistors,
            "estimated_area_mm2": round(area_mm2, 2),
            "target_process": "7nm",
            "fits_hc1": total_bits <= 50e9,
        }


class UnikernelExporter:
    """
    Exporta modelo cuantizado como imagen de unikernel autocontenida.
    Compatible con: NanoVMs/Nanos, Unikraft + Firecracker.
    
    Genera:
    - Dockerfile minimalista con servidor de inferencia
    - Configuración Unikraft (kraft.yaml)
    - Script de Firecracker (firecracker.json)
    - Imagen OCI lista para despliegue
    """
    
    def __init__(self, runtime: str = "unikraft"):
        """runtime: unikraft, nanovms, firecracker"""
        self.runtime = runtime
    
    def export(self, quantized_model: Dict[str, QuantizedTensor],
               output_dir: str, model_name: str = "tenminator-model") -> str:
        """Genera los archivos de despliegue para unikernel."""
        os.makedirs(output_dir, exist_ok=True)
        
        # 1. Guardar modelo en formato binario compacto
        model_path = os.path.join(output_dir, f"{model_name}.tmq")
        self._save_compact(quantized_model, model_path)
        
        # 2. Generar servidor de inferencia mínimo
        server_path = os.path.join(output_dir, "serve.py")
        self._generate_server(server_path, model_name)
        
        # 3. Configuración según runtime
        if self.runtime == "unikraft":
            self._generate_kraft_yaml(output_dir, model_name)
        elif self.runtime == "nanovms":
            self._generate_nanos_config(output_dir, model_name)
        
        # 4. Firecracker config (compatible con ambos)
        self._generate_firecracker_config(output_dir, model_name)
        
        # 5. Dockerfile como fallback
        self._generate_dockerfile(output_dir, model_name)
        
        # 6. Script de despliegue
        self._generate_deploy_script(output_dir, model_name)
        
        return output_dir
    
    def _save_compact(self, model: Dict[str, QuantizedTensor], path: str):
        """Guarda modelo en formato binario compacto .tmq (TenMiNaTor Quantized)."""
        import pickle
        data = {}
        for name, qt in model.items():
            data[name] = {
                "data": qt.data, "scales": qt.scales,
                "zeros": qt.zeros, "bits": qt.bits,
                "group_size": qt.group_size, "format_name": qt.format_name,
                "shape": qt.shape,
            }
        with open(path, "wb") as f:
            pickle.dump(data, f, protocol=4)
    
    def _generate_server(self, path: str, model_name: str):
        code = f'''#!/usr/bin/env python3
"""Servidor de inferencia mínimo para unikernel. Modelo: {model_name}"""
import json, pickle, os
from http.server import HTTPServer, BaseHTTPRequestHandler

MODEL_PATH = os.environ.get("MODEL_PATH", "{model_name}.tmq")
model_data = None

def load_model():
    global model_data
    with open(MODEL_PATH, "rb") as f:
        model_data = pickle.load(f)
    print(f"Modelo cargado: {{len(model_data)}} capas")

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            self._json(200, {{"status": "ok", "model": "{model_name}", "layers": len(model_data or {{}})}})
        elif self.path == "/v1/models":
            self._json(200, {{"data": [{{"id": "{model_name}", "object": "model"}}]}})
        else:
            self._json(404, {{"error": "not found"}})
    
    def do_POST(self):
        if self.path == "/v1/chat/completions":
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length)) if length else {{}}
            # Inferencia simplificada (placeholder para motor real)
            self._json(200, {{
                "choices": [{{"message": {{"role": "assistant", "content": "Modelo {model_name} cargado en unikernel. Inferencia activa."}}}}],
                "model": "{model_name}",
                "usage": {{"prompt_tokens": 0, "completion_tokens": 0}}
            }})
        else:
            self._json(404, {{"error": "not found"}})
    
    def _json(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def log_message(self, fmt, *args):
        pass  # Silenciar logs para unikernel

if __name__ == "__main__":
    load_model()
    port = int(os.environ.get("PORT", "8080"))
    server = HTTPServer(("0.0.0.0", port), Handler)
    print(f"Servidor en puerto {{port}}")
    server.serve_forever()
'''
        with open(path, "w") as f:
            f.write(code)
    
    def _generate_kraft_yaml(self, output_dir: str, model_name: str):
        yaml_content = f"""# Unikraft configuration for {model_name}
specification: v0.6
name: {model_name}
unikraft:
  version: stable
  kconfig:
    CONFIG_LIBVFSCORE_AUTOMOUNT_UP: "y"

targets:
  - architecture: x86_64
    platform: qemu
  - architecture: x86_64
    platform: firecracker
  - architecture: aarch64
    platform: qemu

libraries:
  musl: stable
  lwip: stable

volumes:
  model:
    driver: 9pfs

rootfs: ./rootfs

cmd: ["python3", "/app/serve.py"]
"""
        with open(os.path.join(output_dir, "kraft.yaml"), "w") as f:
            f.write(yaml_content)
    
    def _generate_nanos_config(self, output_dir: str, model_name: str):
        config = {
            "Args": ["python3", "/app/serve.py"],
            "Env": {"MODEL_PATH": f"/app/{model_name}.tmq", "PORT": "8080"},
            "Files": ["/app"],
            "MapDirs": {"/app": "./"},
            "Memory": "2G",
            "BaseVolumeSz": "1G",
        }
        with open(os.path.join(output_dir, "nanos_config.json"), "w") as f:
            json.dump(config, f, indent=2)
    
    def _generate_firecracker_config(self, output_dir: str, model_name: str):
        config = {
            "boot-source": {
                "kernel_image_path": "./vmlinux",
                "boot_args": "console=ttyS0 reboot=k panic=1 pci=off"
            },
            "drives": [{
                "drive_id": "rootfs",
                "path_on_host": f"./{model_name}-rootfs.ext4",
                "is_root_device": True,
                "is_read_only": False
            }],
            "machine-config": {
                "vcpu_count": 2,
                "mem_size_mib": 2048,
                "smt": False
            },
            "network-interfaces": [{
                "iface_id": "eth0",
                "guest_mac": "AA:FC:00:00:00:01",
                "host_dev_name": "tap0"
            }]
        }
        with open(os.path.join(output_dir, "firecracker.json"), "w") as f:
            json.dump(config, f, indent=2)
    
    def _generate_dockerfile(self, output_dir: str, model_name: str):
        dockerfile = f"""FROM python:3.11-slim AS runtime
WORKDIR /app
COPY {model_name}.tmq serve.py ./
ENV MODEL_PATH=/app/{model_name}.tmq PORT=8080
EXPOSE 8080
CMD ["python3", "serve.py"]
"""
        with open(os.path.join(output_dir, "Dockerfile"), "w") as f:
            f.write(dockerfile)
    
    def _generate_deploy_script(self, output_dir: str, model_name: str):
        script = f"""#!/bin/bash
# Despliegue de {model_name} en unikernel
set -e

MODE="${{1:-docker}}"

case "$MODE" in
  docker)
    echo "Construyendo imagen Docker..."
    docker build -t {model_name}:latest .
    docker run -p 8080:8080 {model_name}:latest
    ;;
  unikraft)
    echo "Construyendo unikernel con Unikraft..."
    kraft build --target x86_64-firecracker
    kraft run -p 8080:8080
    ;;
  nanovms)
    echo "Construyendo unikernel con NanoVMs..."
    ops build -c nanos_config.json serve.py
    ops run -p 8080 serve.py
    ;;
  firecracker)
    echo "Lanzando con Firecracker..."
    firecracker --api-sock /tmp/fc.sock --config-file firecracker.json
    ;;
  local)
    echo "Ejecutando localmente..."
    python3 serve.py
    ;;
  *)
    echo "Uso: ./deploy.sh [docker|unikraft|nanovms|firecracker|local]"
    ;;
esac
"""
        deploy_path = os.path.join(output_dir, "deploy.sh")
        with open(deploy_path, "w") as f:
            f.write(script)
        os.chmod(deploy_path, 0o755)
