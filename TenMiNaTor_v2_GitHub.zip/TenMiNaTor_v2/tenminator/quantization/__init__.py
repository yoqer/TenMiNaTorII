"""
TenMiNaTor Quantization Engine
===============================
Motor de cuantización avanzado con soporte para:
- Q8 (INT8 simétrico/asimétrico)
- Q6 (6-bit mixto)
- Q5 (5-bit K-means)
- Q4_K_M (4-bit K-means medio, estándar GGUF)
- Q3_TQ (3-bit TurboQuant con rotación Hadamard)
- Q2_KIVI (2-bit asimétrico con corrección)
- Q1_BitNet (1.58-bit ternario {-1, 0, +1})
- NVFP4 (4-bit floating point para Blackwell/Vera Rubin)
- ANT4 (Adaptive Numerical Type 4-bit)
- Chip export (Taalas HC1/HC2 format)
"""

from .engine import Quantizer, QuantConfig
from .formats import (
    quantize_q8, quantize_q6, quantize_q5, quantize_q4,
    quantize_q3_turbo, quantize_q2_kivi, quantize_q1_bitnet,
    quantize_nvfp4, quantize_ant4,
    dequantize
)
from .export import GGUFExporter, ChipExporter, UnikernelExporter

__all__ = [
    "Quantizer", "QuantConfig",
    "quantize_q8", "quantize_q6", "quantize_q5", "quantize_q4",
    "quantize_q3_turbo", "quantize_q2_kivi", "quantize_q1_bitnet",
    "quantize_nvfp4", "quantize_ant4",
    "dequantize",
    "GGUFExporter", "ChipExporter", "UnikernelExporter",
]
