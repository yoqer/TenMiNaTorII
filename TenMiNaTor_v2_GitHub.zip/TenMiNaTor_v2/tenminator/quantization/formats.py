"""
Formatos de cuantización: Q8, Q6, Q5, Q4, Q3 (TurboQuant), Q2 (KIVI), Q1 (BitNet),
NVFP4 (Blackwell), ANT4 (Adaptive Numerical Type).
"""
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any


@dataclass
class QuantizedTensor:
    """Tensor cuantizado con metadatos para reconstrucción."""
    data: np.ndarray          # Datos cuantizados (int o packed bits)
    scales: np.ndarray        # Factores de escala por grupo
    zeros: Optional[np.ndarray] = None  # Zero-points (asimétrico)
    bits: int = 8             # Bits por peso
    group_size: int = 128     # Tamaño de grupo para escala
    format_name: str = "Q8"   # Nombre del formato
    shape: tuple = ()         # Forma original
    rotation: Optional[np.ndarray] = None  # Matriz de rotación (TurboQuant)
    codebook: Optional[np.ndarray] = None  # Codebook (QuIP#/BitNet)
    metadata: Optional[Dict[str, Any]] = None


# ═══════════════════════════════════════════════════════════════
# Utilidades compartidas
# ═══════════════════════════════════════════════════════════════

def _group_weights(weights: np.ndarray, group_size: int) -> np.ndarray:
    """Reshape pesos en grupos para cuantización por grupo."""
    flat = weights.flatten()
    pad_len = (group_size - len(flat) % group_size) % group_size
    if pad_len > 0:
        flat = np.concatenate([flat, np.zeros(pad_len, dtype=flat.dtype)])
    return flat.reshape(-1, group_size)


def _hadamard_matrix(n: int) -> np.ndarray:
    """Genera matriz de Hadamard normalizada de tamaño n (potencia de 2)."""
    if n == 1:
        return np.array([[1.0]])
    h = _hadamard_matrix(n // 2)
    return np.block([[h, h], [h, -h]]) / np.sqrt(2)


def _random_hadamard_rotation(dim: int, seed: int = 42) -> np.ndarray:
    """Rotación Hadamard aleatoria para distribución uniforme de outliers."""
    rng = np.random.RandomState(seed)
    # Pad a potencia de 2
    n = 1
    while n < dim:
        n *= 2
    H = _hadamard_matrix(n)
    # Diagonal aleatoria de signos
    D = np.diag(rng.choice([-1.0, 1.0], size=n))
    R = H @ D
    return R[:dim, :dim].astype(np.float32)


# ═══════════════════════════════════════════════════════════════
# Q8 — INT8 simétrico (estándar)
# ═══════════════════════════════════════════════════════════════

def quantize_q8(weights: np.ndarray, group_size: int = 128) -> QuantizedTensor:
    """Cuantización INT8 simétrica por grupo."""
    shape = weights.shape
    groups = _group_weights(weights, group_size)
    
    # Escala simétrica: max(abs) / 127
    scales = np.max(np.abs(groups), axis=1, keepdims=True) / 127.0
    scales = np.where(scales == 0, 1.0, scales)
    
    quantized = np.clip(np.round(groups / scales), -128, 127).astype(np.int8)
    
    return QuantizedTensor(
        data=quantized, scales=scales.flatten(),
        bits=8, group_size=group_size,
        format_name="Q8_0", shape=shape
    )


# ═══════════════════════════════════════════════════════════════
# Q6 — 6-bit mixto (Taalas HC1 style)
# ═══════════════════════════════════════════════════════════════

def quantize_q6(weights: np.ndarray, group_size: int = 64) -> QuantizedTensor:
    """Cuantización 6-bit simétrica. Rango [-31, 31]."""
    shape = weights.shape
    groups = _group_weights(weights, group_size)
    
    scales = np.max(np.abs(groups), axis=1, keepdims=True) / 31.0
    scales = np.where(scales == 0, 1.0, scales)
    
    quantized = np.clip(np.round(groups / scales), -32, 31).astype(np.int8)
    
    return QuantizedTensor(
        data=quantized, scales=scales.flatten(),
        bits=6, group_size=group_size,
        format_name="Q6_K", shape=shape
    )


# ═══════════════════════════════════════════════════════════════
# Q5 — 5-bit K-means
# ═══════════════════════════════════════════════════════════════

def quantize_q5(weights: np.ndarray, group_size: int = 64) -> QuantizedTensor:
    """Cuantización 5-bit simétrica. Rango [-15, 15]."""
    shape = weights.shape
    groups = _group_weights(weights, group_size)
    
    scales = np.max(np.abs(groups), axis=1, keepdims=True) / 15.0
    scales = np.where(scales == 0, 1.0, scales)
    
    quantized = np.clip(np.round(groups / scales), -16, 15).astype(np.int8)
    
    return QuantizedTensor(
        data=quantized, scales=scales.flatten(),
        bits=5, group_size=group_size,
        format_name="Q5_K_M", shape=shape
    )


# ═══════════════════════════════════════════════════════════════
# Q4 — 4-bit K-means medio (GGUF estándar)
# ═══════════════════════════════════════════════════════════════

def quantize_q4(weights: np.ndarray, group_size: int = 32) -> QuantizedTensor:
    """Cuantización 4-bit asimétrica (Q4_K_M). Rango [0, 15]."""
    shape = weights.shape
    groups = _group_weights(weights, group_size)
    
    mins = np.min(groups, axis=1, keepdims=True)
    maxs = np.max(groups, axis=1, keepdims=True)
    
    scales = (maxs - mins) / 15.0
    scales = np.where(scales == 0, 1.0, scales)
    zeros = -mins / scales
    
    quantized = np.clip(np.round((groups - mins) / scales), 0, 15).astype(np.uint8)
    
    return QuantizedTensor(
        data=quantized, scales=scales.flatten(),
        zeros=zeros.flatten(),
        bits=4, group_size=group_size,
        format_name="Q4_K_M", shape=shape
    )


# ═══════════════════════════════════════════════════════════════
# Q3 TurboQuant — 3-bit con rotación Hadamard (Google, ICLR 2026)
# ═══════════════════════════════════════════════════════════════

def quantize_q3_turbo(weights: np.ndarray, group_size: int = 32) -> QuantizedTensor:
    """
    Cuantización 3-bit TurboQuant.
    
    Técnica: Rotación Hadamard aleatoria para distribuir outliers uniformemente,
    seguida de cuantización adaptativa en dominio rotado.
    
    Basado en: "TurboQuant: Redefining AI efficiency with extreme compression"
    (Google Research + NYU, ICLR 2026)
    
    Rango cuantizado: [-3, 3] (7 niveles, 3 bits)
    """
    shape = weights.shape
    flat = weights.flatten().astype(np.float32)
    dim = len(flat)
    
    # Paso 1: Rotación Hadamard para distribuir outliers
    # Pad a múltiplo de group_size
    pad_len = (group_size - dim % group_size) % group_size
    if pad_len > 0:
        flat = np.concatenate([flat, np.zeros(pad_len, dtype=np.float32)])
    
    groups = flat.reshape(-1, group_size)
    
    # Rotación por grupo (eficiente en memoria)
    R = _random_hadamard_rotation(group_size, seed=42)
    rotated = groups @ R.T
    
    # Paso 2: Cuantización adaptativa en dominio rotado
    # Escala por grupo con corrección de outliers
    abs_max = np.max(np.abs(rotated), axis=1, keepdims=True)
    # Corrección TurboQuant: usar percentil 99.5 en vez de max
    p995 = np.percentile(np.abs(rotated), 99.5, axis=1, keepdims=True)
    scales = p995 / 3.0
    scales = np.where(scales == 0, 1.0, scales)
    
    # Cuantizar a [-3, 3]
    quantized = np.clip(np.round(rotated / scales), -3, 3).astype(np.int8)
    
    return QuantizedTensor(
        data=quantized, scales=scales.flatten(),
        bits=3, group_size=group_size,
        format_name="TQ3_0", shape=shape,
        rotation=R,
        metadata={"method": "turboquant", "percentile": 99.5}
    )


# ═══════════════════════════════════════════════════════════════
# Q2 KIVI — 2-bit asimétrico (ICML 2024)
# ═══════════════════════════════════════════════════════════════

def quantize_q2_kivi(weights: np.ndarray, group_size: int = 16) -> QuantizedTensor:
    """
    Cuantización 2-bit asimétrica KIVI.
    
    Técnica: Cuantización asimétrica con zero-point por grupo pequeño (16),
    preservando outliers en canales residuales.
    
    Basado en: "KIVI: A Tuning-Free Asymmetric 2bit Quantization for KV Cache"
    (ICML 2024)
    
    Rango: [0, 3] (4 niveles, 2 bits)
    """
    shape = weights.shape
    groups = _group_weights(weights, group_size)
    
    mins = np.min(groups, axis=1, keepdims=True)
    maxs = np.max(groups, axis=1, keepdims=True)
    
    scales = (maxs - mins) / 3.0
    scales = np.where(scales == 0, 1.0, scales)
    zeros = mins
    
    quantized = np.clip(np.round((groups - mins) / scales), 0, 3).astype(np.uint8)
    
    # Canal residual: guardar los outliers que exceden 2 sigma
    reconstructed = quantized.astype(np.float32) * scales + zeros
    residual = groups - reconstructed
    outlier_mask = np.abs(residual) > 2 * np.std(residual, axis=1, keepdims=True)
    outlier_values = np.where(outlier_mask, residual, 0).astype(np.float16)
    
    return QuantizedTensor(
        data=quantized, scales=scales.flatten(),
        zeros=zeros.flatten(),
        bits=2, group_size=group_size,
        format_name="Q2_KIVI", shape=shape,
        metadata={
            "method": "kivi_asymmetric",
            "outlier_values": outlier_values,
            "outlier_mask": outlier_mask
        }
    )


# ═══════════════════════════════════════════════════════════════
# Q1 BitNet — 1.58-bit ternario (Microsoft, JMLR 2025)
# ═══════════════════════════════════════════════════════════════

def quantize_q1_bitnet(weights: np.ndarray) -> QuantizedTensor:
    """
    Cuantización 1.58-bit BitNet b1.58.
    
    Técnica: Pesos ternarios {-1, 0, +1} usando absmean quantization.
    Cada peso se cuantiza al signo más cercano, con umbral en la media absoluta.
    
    Basado en: "The Era of 1-bit LLMs: All Large Language Models are in 1.58 Bits"
    (Microsoft Research, 2024) y "BitNet b1.58 2B4T" (2025)
    
    Almacenamiento: 2 bits por peso (codificación: 00=-1, 01=0, 10=+1)
    """
    shape = weights.shape
    flat = weights.flatten().astype(np.float32)
    
    # AbsMean quantization (BitNet b1.58)
    gamma = np.mean(np.abs(flat))
    
    if gamma == 0:
        quantized = np.zeros_like(flat, dtype=np.int8)
    else:
        scaled = flat / gamma
        # Ternario: round-to-nearest de {-1, 0, +1}
        quantized = np.clip(np.round(scaled), -1, 1).astype(np.int8)
    
    # Pack en 2 bits: -1→0b00, 0→0b01, +1→0b10
    packed = (quantized + 1).astype(np.uint8)  # Ahora 0, 1, 2
    
    # Empaquetar 4 valores por byte
    pad_len = (4 - len(packed) % 4) % 4
    if pad_len > 0:
        packed = np.concatenate([packed, np.zeros(pad_len, dtype=np.uint8)])
    
    packed_bytes = (
        packed[0::4] |
        (packed[1::4] << 2) |
        (packed[2::4] << 4) |
        (packed[3::4] << 6)
    )
    
    return QuantizedTensor(
        data=packed_bytes,
        scales=np.array([gamma], dtype=np.float32),
        bits=1, group_size=len(flat),
        format_name="Q1_BitNet", shape=shape,
        metadata={
            "method": "bitnet_b158",
            "gamma": float(gamma),
            "ternary_values": [-1, 0, 1],
            "packing": "2bit_per_weight_4_per_byte",
            "original_length": len(flat)
        }
    )


# ═══════════════════════════════════════════════════════════════
# NVFP4 — NVIDIA Blackwell FP4 (2025)
# ═══════════════════════════════════════════════════════════════

def quantize_nvfp4(weights: np.ndarray, block_size: int = 16) -> QuantizedTensor:
    """
    Cuantización NVFP4 (NVIDIA Floating Point 4-bit).
    
    Formato: 1 bit signo + 2 bits exponente + 1 bit mantisa
    Con micro-scaling: factor de escala FP8 compartido por bloque de 16.
    
    Nativo en: NVIDIA Blackwell (B200, B300, RTX 5090), Vera Rubin
    
    Basado en: "Introducing NVFP4 for Efficient and Accurate Low-Precision Inference"
    (NVIDIA, 2025)
    """
    shape = weights.shape
    groups = _group_weights(weights, block_size)
    
    # Micro-scaling: escala FP8 por bloque
    abs_max = np.max(np.abs(groups), axis=1, keepdims=True)
    scales = abs_max / 6.0  # FP4 max representable ≈ 6.0
    scales = np.where(scales == 0, 1.0, scales)
    
    normalized = groups / scales
    
    # FP4 lookup: 16 valores posibles
    # {±0, ±0.5, ±1, ±1.5, ±2, ±3, ±4, ±6}
    fp4_values = np.array([
        -6, -4, -3, -2, -1.5, -1, -0.5, 0,
        0, 0.5, 1, 1.5, 2, 3, 4, 6
    ], dtype=np.float32)
    
    # Cuantizar al valor FP4 más cercano
    diffs = np.abs(normalized[:, :, None] - fp4_values[None, None, :])
    indices = np.argmin(diffs, axis=2).astype(np.uint8)
    
    return QuantizedTensor(
        data=indices, scales=scales.flatten(),
        bits=4, group_size=block_size,
        format_name="NVFP4", shape=shape,
        codebook=fp4_values,
        metadata={
            "method": "nvfp4_microscaling",
            "block_size": block_size,
            "hardware": ["NVIDIA Blackwell", "NVIDIA Vera Rubin"],
            "format": "1s+2e+1m with FP8 block scale"
        }
    )


# ═══════════════════════════════════════════════════════════════
# ANT4 — Adaptive Numerical Type 4-bit (IEEE 2022)
# ═══════════════════════════════════════════════════════════════

def quantize_ant4(weights: np.ndarray, group_size: int = 32) -> QuantizedTensor:
    """
    Cuantización ANT4 (Adaptive Numerical Type).
    
    Técnica: Selecciona automáticamente el tipo numérico óptimo por capa/canal
    entre INT4, FP4 y POT4 (Power-of-Two), minimizando el error de cuantización.
    
    Basado en: "ANT: Exploiting Adaptive Numerical Data Type for Low-Bit DNN Quantization"
    (IEEE/ACM MICRO 2022, 118 citas) y M-ANT (HPCA 2025, 24 citas)
    """
    shape = weights.shape
    groups = _group_weights(weights, group_size)
    
    # Evaluar 3 tipos numéricos por grupo
    results = {}
    
    # Tipo 1: INT4 simétrico [-7, 7]
    int4_scales = np.max(np.abs(groups), axis=1, keepdims=True) / 7.0
    int4_scales = np.where(int4_scales == 0, 1.0, int4_scales)
    int4_q = np.clip(np.round(groups / int4_scales), -8, 7)
    int4_error = np.mean((groups - int4_q * int4_scales) ** 2, axis=1)
    
    # Tipo 2: FP4 (como NVFP4 pero sin micro-scaling)
    fp4_vals = np.array([-6, -4, -3, -2, -1.5, -1, -0.5, 0, 0, 0.5, 1, 1.5, 2, 3, 4, 6])
    fp4_scales = np.max(np.abs(groups), axis=1, keepdims=True) / 6.0
    fp4_scales = np.where(fp4_scales == 0, 1.0, fp4_scales)
    fp4_norm = groups / fp4_scales
    fp4_diffs = np.abs(fp4_norm[:, :, None] - fp4_vals[None, None, :])
    fp4_idx = np.argmin(fp4_diffs, axis=2)
    fp4_recon = fp4_vals[fp4_idx] * fp4_scales
    fp4_error = np.mean((groups - fp4_recon) ** 2, axis=1)
    
    # Tipo 3: POT4 (Power-of-Two) [-8, -4, -2, -1, 0, 1, 2, 4]
    pot4_vals = np.array([-8, -4, -2, -1, -0.5, 0, 0.5, 1, 1, 2, 4, 8, 0, 0, 0, 0])
    pot4_scales = np.max(np.abs(groups), axis=1, keepdims=True) / 8.0
    pot4_scales = np.where(pot4_scales == 0, 1.0, pot4_scales)
    pot4_norm = groups / pot4_scales
    pot4_diffs = np.abs(pot4_norm[:, :, None] - pot4_vals[None, None, :])
    pot4_idx = np.argmin(pot4_diffs, axis=2)
    pot4_recon = pot4_vals[pot4_idx] * pot4_scales
    pot4_error = np.mean((groups - pot4_recon) ** 2, axis=1)
    
    # Seleccionar tipo óptimo por grupo
    errors = np.stack([int4_error, fp4_error, pot4_error], axis=1)
    best_type = np.argmin(errors, axis=1)  # 0=INT4, 1=FP4, 2=POT4
    
    # Construir resultado con tipo adaptativo
    n_groups = len(groups)
    quantized = np.zeros_like(groups, dtype=np.int8)
    final_scales = np.zeros(n_groups, dtype=np.float32)
    
    for i in range(n_groups):
        if best_type[i] == 0:  # INT4
            final_scales[i] = int4_scales[i, 0]
            quantized[i] = np.clip(np.round(groups[i] / final_scales[i]), -8, 7).astype(np.int8)
        elif best_type[i] == 1:  # FP4
            final_scales[i] = fp4_scales[i, 0]
            quantized[i] = fp4_idx[i].astype(np.int8)
        else:  # POT4
            final_scales[i] = pot4_scales[i, 0]
            quantized[i] = pot4_idx[i].astype(np.int8)
    
    type_names = {0: "INT4", 1: "FP4", 2: "POT4"}
    type_counts = {type_names[t]: int(np.sum(best_type == t)) for t in range(3)}
    
    return QuantizedTensor(
        data=quantized, scales=final_scales,
        bits=4, group_size=group_size,
        format_name="ANT4", shape=shape,
        metadata={
            "method": "adaptive_numerical_type",
            "type_per_group": best_type.tolist(),
            "type_distribution": type_counts,
            "codebooks": {"FP4": fp4_vals.tolist(), "POT4": pot4_vals.tolist()}
        }
    )


# ═══════════════════════════════════════════════════════════════
# Dequantización universal
# ═══════════════════════════════════════════════════════════════

def dequantize(qt: QuantizedTensor) -> np.ndarray:
    """Reconstruye tensor original desde formato cuantizado."""
    
    if qt.format_name == "Q1_BitNet":
        # Desempaquetar 2-bit
        meta = qt.metadata or {}
        orig_len = meta.get("original_length", np.prod(qt.shape))
        packed = qt.data
        unpacked = np.zeros(len(packed) * 4, dtype=np.int8)
        unpacked[0::4] = (packed & 0x03).astype(np.int8) - 1
        unpacked[1::4] = ((packed >> 2) & 0x03).astype(np.int8) - 1
        unpacked[2::4] = ((packed >> 4) & 0x03).astype(np.int8) - 1
        unpacked[3::4] = ((packed >> 6) & 0x03).astype(np.int8) - 1
        result = unpacked[:orig_len].astype(np.float32) * qt.scales[0]
        return result.reshape(qt.shape)
    
    if qt.format_name == "NVFP4":
        # Lookup en codebook
        groups = qt.data.astype(np.int32)
        n_groups = len(qt.scales)
        gs = qt.group_size
        recon = qt.codebook[groups] * qt.scales.reshape(-1, 1)
        flat = recon.flatten()[:int(np.prod(qt.shape))]
        return flat.reshape(qt.shape)
    
    if qt.format_name == "ANT4":
        meta = qt.metadata or {}
        type_per_group = meta.get("type_per_group", [])
        codebooks = meta.get("codebooks", {})
        fp4_vals = np.array(codebooks.get("FP4", []))
        pot4_vals = np.array(codebooks.get("POT4", []))
        
        n_groups = len(qt.scales)
        gs = qt.group_size
        recon = np.zeros((n_groups, gs), dtype=np.float32)
        
        for i in range(n_groups):
            t = type_per_group[i] if i < len(type_per_group) else 0
            if t == 0:  # INT4
                recon[i] = qt.data[i].astype(np.float32) * qt.scales[i]
            elif t == 1:  # FP4
                recon[i] = fp4_vals[qt.data[i].astype(np.int32)] * qt.scales[i]
            else:  # POT4
                recon[i] = pot4_vals[qt.data[i].astype(np.int32)] * qt.scales[i]
        
        flat = recon.flatten()[:int(np.prod(qt.shape))]
        return flat.reshape(qt.shape)
    
    if qt.format_name == "TQ3_0":
        # Dequantizar + rotación inversa
        recon = qt.data.astype(np.float32) * qt.scales.reshape(-1, 1)
        if qt.rotation is not None:
            recon = recon @ qt.rotation  # R^T @ R = I (ortogonal)
        flat = recon.flatten()[:int(np.prod(qt.shape))]
        return flat.reshape(qt.shape)
    
    if qt.format_name == "Q2_KIVI":
        recon = qt.data.astype(np.float32) * qt.scales.reshape(-1, 1) + qt.zeros.reshape(-1, 1)
        # Añadir residuales de outliers si existen
        meta = qt.metadata or {}
        outlier_values = meta.get("outlier_values")
        if outlier_values is not None:
            recon += outlier_values.astype(np.float32)
        flat = recon.flatten()[:int(np.prod(qt.shape))]
        return flat.reshape(qt.shape)
    
    # Formatos estándar (Q8, Q6, Q5, Q4)
    data_f = qt.data.astype(np.float32)
    if qt.zeros is not None:
        # Asimétrico: x_recon = (q - zero) * scale
        recon = (data_f - qt.zeros.reshape(-1, 1)) * qt.scales.reshape(-1, 1)
    else:
        # Simétrico: x_recon = q * scale
        recon = data_f * qt.scales.reshape(-1, 1)
    
    flat = recon.flatten()[:int(np.prod(qt.shape))]
    return flat.reshape(qt.shape)
