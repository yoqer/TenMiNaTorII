"""
Motor de cuantización de alto nivel para TenMiNaTor.
Interfaz unificada para todos los formatos de cuantización.
"""
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, List
from .formats import (
    QuantizedTensor,
    quantize_q8, quantize_q6, quantize_q5, quantize_q4,
    quantize_q3_turbo, quantize_q2_kivi, quantize_q1_bitnet,
    quantize_nvfp4, quantize_ant4,
    dequantize
)


@dataclass
class QuantConfig:
    """Configuración de cuantización."""
    bits: int = 4                    # Bits objetivo (1, 2, 3, 4, 5, 6, 8)
    method: str = "auto"             # auto, symmetric, asymmetric, turboquant, kivi, bitnet, nvfp4, ant4
    group_size: int = 32             # Tamaño de grupo
    calibration_samples: int = 128   # Muestras para calibración
    preserve_outliers: bool = True   # Preservar outliers en canal residual
    mixed_precision: bool = False    # Capas sensibles en mayor precisión
    sensitive_layers: List[str] = field(default_factory=list)  # Capas a proteger
    sensitive_bits: int = 8          # Bits para capas sensibles

    def __post_init__(self):
        valid_bits = {1, 2, 3, 4, 5, 6, 8}
        if self.bits not in valid_bits:
            raise ValueError(f"bits debe ser uno de {valid_bits}, recibido: {self.bits}")


# Tabla de recomendaciones por VRAM
VRAM_TABLE = {
    # (modelo_params_B, bits): vram_gb_estimado
    (7, 8): 8, (7, 6): 6, (7, 5): 5, (7, 4): 4, (7, 3): 3, (7, 2): 2, (7, 1): 1.5,
    (13, 8): 14, (13, 6): 11, (13, 5): 9, (13, 4): 8, (13, 3): 6, (13, 2): 4, (13, 1): 2.5,
    (30, 8): 32, (30, 6): 24, (30, 5): 20, (30, 4): 18, (30, 3): 12, (30, 2): 8, (30, 1): 5,
    (40, 8): 42, (40, 6): 32, (40, 5): 26, (40, 4): 24, (40, 3): 16, (40, 2): 10, (40, 1): 7,
    (70, 8): 72, (70, 6): 54, (70, 5): 44, (70, 4): 40, (70, 3): 28, (70, 2): 18, (70, 1): 12,
}


class Quantizer:
    """
    Motor de cuantización unificado.
    
    Uso básico:
        q = Quantizer(QuantConfig(bits=4))
        result = q.quantize_model(model_weights)
        
    Uso avanzado:
        q = Quantizer(QuantConfig(bits=3, method="turboquant"))
        result = q.quantize_model(model_weights)
        q.save_gguf(result, "model-q3.gguf")
    """
    
    # Mapeo de (bits, method) → función
    _METHODS = {
        (8, "auto"): quantize_q8,
        (8, "symmetric"): quantize_q8,
        (6, "auto"): quantize_q6,
        (6, "symmetric"): quantize_q6,
        (5, "auto"): quantize_q5,
        (5, "symmetric"): quantize_q5,
        (4, "auto"): quantize_q4,
        (4, "asymmetric"): quantize_q4,
        (4, "nvfp4"): quantize_nvfp4,
        (4, "ant4"): quantize_ant4,
        (3, "auto"): quantize_q3_turbo,
        (3, "turboquant"): quantize_q3_turbo,
        (2, "auto"): quantize_q2_kivi,
        (2, "kivi"): quantize_q2_kivi,
        (1, "auto"): quantize_q1_bitnet,
        (1, "bitnet"): quantize_q1_bitnet,
    }
    
    FORMAT_INFO = {
        "Q8_0":      {"bits": 8, "desc": "INT8 simétrico",           "loss": "Mínima",  "speed": "1x",   "hw": "CPU, GPU, NPU"},
        "Q6_K":      {"bits": 6, "desc": "6-bit K-means",            "loss": "Muy baja", "speed": "1.3x", "hw": "CPU, GPU"},
        "Q5_K_M":    {"bits": 5, "desc": "5-bit K-means medio",      "loss": "Baja",    "speed": "1.5x", "hw": "CPU, GPU"},
        "Q4_K_M":    {"bits": 4, "desc": "4-bit K-means medio",      "loss": "Baja",    "speed": "2x",   "hw": "CPU, GPU, NPU"},
        "TQ3_0":     {"bits": 3, "desc": "3-bit TurboQuant Hadamard", "loss": "Media",   "speed": "2.5x", "hw": "CPU, GPU"},
        "Q2_KIVI":   {"bits": 2, "desc": "2-bit KIVI asimétrico",    "loss": "Alta",    "speed": "3x",   "hw": "CPU, GPU"},
        "Q1_BitNet": {"bits": 1, "desc": "1.58-bit ternario",        "loss": "Alta",    "speed": "4x",   "hw": "CPU, NPU, Chip"},
        "NVFP4":     {"bits": 4, "desc": "FP4 micro-scaling NVIDIA",  "loss": "Baja",    "speed": "3x",   "hw": "Blackwell, Vera Rubin"},
        "ANT4":      {"bits": 4, "desc": "Adaptive Numerical Type",   "loss": "Mínima",  "speed": "2x",   "hw": "GPU, FPGA, Chip"},
    }
    
    def __init__(self, config: Optional[QuantConfig] = None):
        self.config = config or QuantConfig()
    
    def quantize_weights(self, weights: np.ndarray, layer_name: str = "") -> QuantizedTensor:
        """Cuantiza un tensor de pesos según la configuración."""
        cfg = self.config
        
        # Mixed precision: capas sensibles en mayor precisión
        if cfg.mixed_precision and layer_name in cfg.sensitive_layers:
            bits = cfg.sensitive_bits
            method = "auto"
        else:
            bits = cfg.bits
            method = cfg.method
        
        key = (bits, method)
        if key not in self._METHODS:
            raise ValueError(
                f"Combinación no soportada: bits={bits}, method={method}. "
                f"Métodos disponibles para {bits}-bit: "
                f"{[m for (b, m) in self._METHODS if b == bits]}"
            )
        
        fn = self._METHODS[key]
        
        # Q1 BitNet no usa group_size
        if bits == 1:
            return fn(weights)
        
        return fn(weights, group_size=cfg.group_size)
    
    def quantize_model(self, state_dict: Dict[str, np.ndarray]) -> Dict[str, QuantizedTensor]:
        """Cuantiza un modelo completo (state_dict)."""
        result = {}
        total_original = 0
        total_quantized = 0
        
        for name, weights in state_dict.items():
            qt = self.quantize_weights(weights, layer_name=name)
            result[name] = qt
            
            original_bytes = weights.nbytes
            quant_bytes = qt.data.nbytes + qt.scales.nbytes
            if qt.zeros is not None:
                quant_bytes += qt.zeros.nbytes
            
            total_original += original_bytes
            total_quantized += quant_bytes
        
        compression = total_original / max(total_quantized, 1)
        self._last_stats = {
            "layers": len(result),
            "original_mb": total_original / 1024 / 1024,
            "quantized_mb": total_quantized / 1024 / 1024,
            "compression_ratio": round(compression, 2),
            "format": self.config.method,
            "bits": self.config.bits,
        }
        
        return result
    
    def dequantize_model(self, quantized_dict: Dict[str, QuantizedTensor]) -> Dict[str, np.ndarray]:
        """Reconstruye un modelo desde formato cuantizado."""
        return {name: dequantize(qt) for name, qt in quantized_dict.items()}
    
    def measure_error(self, original: np.ndarray, quantized: QuantizedTensor) -> Dict[str, float]:
        """Mide el error de cuantización."""
        reconstructed = dequantize(quantized)
        
        # Recortar al tamaño original si hay padding
        orig_flat = original.flatten()
        recon_flat = reconstructed.flatten()[:len(orig_flat)]
        
        mse = float(np.mean((orig_flat - recon_flat) ** 2))
        mae = float(np.mean(np.abs(orig_flat - recon_flat)))
        
        orig_var = float(np.var(orig_flat))
        snr = 10 * np.log10(orig_var / max(mse, 1e-10)) if orig_var > 0 else float('inf')
        
        max_error = float(np.max(np.abs(orig_flat - recon_flat)))
        cosine_sim = float(
            np.dot(orig_flat, recon_flat) /
            (np.linalg.norm(orig_flat) * np.linalg.norm(recon_flat) + 1e-10)
        )
        
        return {
            "mse": round(mse, 8),
            "mae": round(mae, 8),
            "snr_db": round(snr, 2),
            "max_error": round(max_error, 8),
            "cosine_similarity": round(cosine_sim, 6),
            "compression_ratio": round(original.nbytes / max(quantized.data.nbytes, 1), 2),
        }
    
    @staticmethod
    def recommend(model_params_b: float, vram_gb: float) -> Dict[str, Any]:
        """Recomienda el formato de cuantización óptimo dado el modelo y la VRAM."""
        recommendations = []
        
        # Encontrar el tamaño de modelo más cercano
        sizes = [7, 13, 30, 40, 70]
        closest = min(sizes, key=lambda x: abs(x - model_params_b))
        
        for bits in [8, 6, 5, 4, 3, 2, 1]:
            key = (closest, bits)
            needed = VRAM_TABLE.get(key, bits * closest / 8 * 1.2)
            fits = needed <= vram_gb
            
            # Buscar el format_name correspondiente
            format_map = {8: "Q8_0", 6: "Q6_K", 5: "Q5_K_M", 4: "Q4_K_M", 3: "TQ3_0", 2: "Q2_KIVI", 1: "Q1_BitNet"}
            fname = format_map[bits]
            info = Quantizer.FORMAT_INFO.get(fname, {})
            
            recommendations.append({
                "format": fname,
                "bits": bits,
                "vram_needed_gb": needed,
                "fits": fits,
                "loss": info.get("loss", "?"),
                "speed": info.get("speed", "?"),
                "recommended": False,
            })
        
        # Marcar el recomendado: el de menor bits que quepa con pérdida aceptable
        for r in recommendations:
            if r["fits"] and r["loss"] in ("Mínima", "Muy baja", "Baja"):
                r["recommended"] = True
                break
        
        return {
            "model_params_b": model_params_b,
            "vram_gb": vram_gb,
            "closest_reference": closest,
            "formats": recommendations,
        }
    
    @property
    def stats(self) -> Dict[str, Any]:
        """Estadísticas de la última cuantización."""
        return getattr(self, "_last_stats", {})
    
    @staticmethod
    def list_formats() -> Dict[str, Dict]:
        """Lista todos los formatos de cuantización disponibles."""
        return dict(Quantizer.FORMAT_INFO)
