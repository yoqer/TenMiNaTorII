"""
TenMiNaTor Neural Network Modules.
"""
import numpy as np
from typing import Optional, List, Dict, Any, Tuple
from .tensor import Tensor
from . import backends as B


class Module:
    """Clase base para todos los módulos de red neuronal."""
    
    def __init__(self):
        self._parameters: Dict[str, Tensor] = {}
        self._modules: Dict[str, 'Module'] = {}
        self._training = True
    
    def forward(self, x: Tensor) -> Tensor:
        raise NotImplementedError
    
    def __call__(self, x: Tensor) -> Tensor:
        return self.forward(x)
    
    def parameters(self) -> List[Tensor]:
        params = list(self._parameters.values())
        for module in self._modules.values():
            params.extend(module.parameters())
        return params
    
    def named_parameters(self) -> Dict[str, Tensor]:
        params = dict(self._parameters)
        for name, module in self._modules.items():
            for param_name, param in module.named_parameters().items():
                params[f"{name}.{param_name}"] = param
        return params

    def layer_gradients(self) -> Dict[str, np.ndarray]:
        grads = {}
        for name, param in self._parameters.items():
            if param.grad is not None:
                grads[name] = param.grad
        return grads

    def train(self, mode: bool = True):
        self._training = mode
        for module in self._modules.values():
            module.train(mode)
        return self
    
    def eval(self):
        return self.train(False)
    
    def state_dict(self) -> Dict[str, np.ndarray]:
        state = {}
        for name, param in self.named_parameters().items():
            state[name] = param.data.copy()
        return state
    
    def load_state_dict(self, state_dict: Dict[str, np.ndarray]):
        for name, param in self.named_parameters().items():
            if name in state_dict:
                param.data = state_dict[name].copy()
    
    def zero_grad(self):
        for param in self.parameters():
            param.zero_grad()
    
    def add_module(self, name: str, module: 'Module'):
        self._modules[name] = module
    
    def __setattr__(self, name, value):
        if isinstance(value, Module) and name not in ('_parameters', '_modules', '_training'):
            if not hasattr(self, '_modules'):
                object.__setattr__(self, '_modules', {})
            self._modules[name] = value
        object.__setattr__(self, name, value)
    
    def count_parameters(self) -> int:
        return sum(np.prod(p.data.shape) for p in self.parameters())


class Parameter(Tensor):
    def __init__(self, data, requires_grad=True):
        super().__init__(data, requires_grad=requires_grad)


class Linear(Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        scale = np.sqrt(2.0 / (in_features + out_features))
        weight_data = np.random.randn(out_features, in_features).astype(np.float32) * scale
        self._parameters['weight'] = Parameter(weight_data)
        if bias:
            bias_data = np.zeros(out_features, dtype=np.float32)
            self._parameters['bias'] = Parameter(bias_data)
        self.use_bias = bias
    
    def forward(self, x: Tensor) -> Tensor:
        weight = self._parameters['weight']
        output = x @ Tensor(weight.data.T, requires_grad=weight.requires_grad)
        if self.use_bias:
            bias = self._parameters['bias']
            output = output + bias
        return output


class Embedding(Module):
    """Tabla de embeddings. Convierte índices enteros en vectores densos."""
    
    def __init__(self, num_embeddings: int, embedding_dim: int):
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        weight_data = np.random.randn(num_embeddings, embedding_dim).astype(np.float32) * 0.02
        self._parameters['weight'] = Parameter(weight_data)
    
    def forward(self, x: Tensor) -> Tensor:
        indices = x.data.astype(int)
        weight = self._parameters['weight']
        embedded = weight.data[indices]
        return Tensor(embedded, requires_grad=weight.requires_grad)


class LayerNorm(Module):
    """Layer Normalization."""
    
    def __init__(self, normalized_shape: int, eps: float = 1e-5):
        super().__init__()
        self.normalized_shape = normalized_shape
        self.eps = eps
        self._parameters['weight'] = Parameter(np.ones(normalized_shape, dtype=np.float32))
        self._parameters['bias'] = Parameter(np.zeros(normalized_shape, dtype=np.float32))
    
    def forward(self, x: Tensor) -> Tensor:
        mean = np.mean(x.data, axis=-1, keepdims=True)
        var = np.var(x.data, axis=-1, keepdims=True)
        x_norm = (x.data - mean) / np.sqrt(var + self.eps)
        weight = self._parameters['weight']
        bias = self._parameters['bias']
        out = x_norm * weight.data + bias.data
        return Tensor(out, requires_grad=x.requires_grad)


class RMSNorm(Module):
    """Root Mean Square Layer Normalization (usado en LLaMA, Gemma)."""
    
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self._parameters['weight'] = Parameter(np.ones(dim, dtype=np.float32))
    
    def forward(self, x: Tensor) -> Tensor:
        rms = np.sqrt(np.mean(x.data ** 2, axis=-1, keepdims=True) + self.eps)
        x_norm = x.data / rms
        out = x_norm * self._parameters['weight'].data
        return Tensor(out, requires_grad=x.requires_grad)


class ReLU(Module):
    """Activación ReLU."""
    def forward(self, x: Tensor) -> Tensor:
        return x.relu()


class GELU(Module):
    """Activación GELU (Gaussian Error Linear Unit)."""
    def forward(self, x: Tensor) -> Tensor:
        # Aproximación tanh: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        data = x.data
        cdf = 0.5 * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (data + 0.044715 * data ** 3)))
        return Tensor(data * cdf, requires_grad=x.requires_grad)


class SiLU(Module):
    """Activación SiLU / Swish (usado en LLaMA, Gemma)."""
    def forward(self, x: Tensor) -> Tensor:
        sigmoid = 1.0 / (1.0 + np.exp(-x.data))
        return Tensor(x.data * sigmoid, requires_grad=x.requires_grad)


class Dropout(Module):
    """Dropout regularization."""
    
    def __init__(self, p: float = 0.1):
        super().__init__()
        self.p = p
    
    def forward(self, x: Tensor) -> Tensor:
        if not self._training or self.p == 0:
            return x
        mask = (np.random.random(x.data.shape) > self.p).astype(np.float32)
        scale = 1.0 / (1.0 - self.p)
        return Tensor(x.data * mask * scale, requires_grad=x.requires_grad)


class Sequential(Module):
    """Contenedor secuencial de módulos."""
    
    def __init__(self, *modules: Module):
        super().__init__()
        for i, module in enumerate(modules):
            self._modules[str(i)] = module
    
    def forward(self, x: Tensor) -> Tensor:
        for module in self._modules.values():
            x = module(x)
        return x
    
    def __len__(self):
        return len(self._modules)
    
    def __getitem__(self, idx):
        return list(self._modules.values())[idx]


class MultiHeadAttention(Module):
    """Multi-Head Attention (Transformer)."""
    
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.0):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        
        self._modules['q_proj'] = Linear(d_model, d_model, bias=False)
        self._modules['k_proj'] = Linear(d_model, d_model, bias=False)
        self._modules['v_proj'] = Linear(d_model, d_model, bias=False)
        self._modules['o_proj'] = Linear(d_model, d_model, bias=False)
        self.dropout = dropout
    
    def forward(self, x: Tensor) -> Tensor:
        batch_size = x.data.shape[0] if len(x.data.shape) == 3 else 1
        seq_len = x.data.shape[-2] if len(x.data.shape) >= 2 else 1
        
        q = self._modules['q_proj'](x)
        k = self._modules['k_proj'](x)
        v = self._modules['v_proj'](x)
        
        # Reshape para multi-head
        def reshape_heads(t, bs, sl):
            data = t.data.reshape(bs, sl, self.n_heads, self.d_k)
            return Tensor(data.transpose(0, 2, 1, 3), requires_grad=t.requires_grad)
        
        q = reshape_heads(q, batch_size, seq_len)
        k = reshape_heads(k, batch_size, seq_len)
        v = reshape_heads(v, batch_size, seq_len)
        
        # Scaled dot-product attention
        scores = q.data @ k.data.transpose(0, 1, 3, 2) / np.sqrt(self.d_k)
        
        # Causal mask
        mask = np.triu(np.ones((seq_len, seq_len)), k=1) * -1e9
        scores = scores + mask
        
        # Softmax
        exp_scores = np.exp(scores - np.max(scores, axis=-1, keepdims=True))
        attn = exp_scores / (np.sum(exp_scores, axis=-1, keepdims=True) + 1e-10)
        
        # Apply attention
        out = attn @ v.data
        out = out.transpose(0, 2, 1, 3).reshape(batch_size, seq_len, self.d_model)
        
        return self._modules['o_proj'](Tensor(out, requires_grad=x.requires_grad))


class TransformerBlock(Module):
    """Bloque Transformer con atención y FFN."""
    
    def __init__(self, d_model: int, n_heads: int, d_ff: int = None, dropout: float = 0.1):
        super().__init__()
        d_ff = d_ff or d_model * 4
        
        self._modules['attention'] = MultiHeadAttention(d_model, n_heads, dropout)
        self._modules['norm1'] = RMSNorm(d_model)
        self._modules['norm2'] = RMSNorm(d_model)
        self._modules['gate_proj'] = Linear(d_model, d_ff, bias=False)
        self._modules['up_proj'] = Linear(d_model, d_ff, bias=False)
        self._modules['down_proj'] = Linear(d_ff, d_model, bias=False)
        self._modules['silu'] = SiLU()
    
    def forward(self, x: Tensor) -> Tensor:
        # Pre-norm attention + residual
        normed = self._modules['norm1'](x)
        attn_out = self._modules['attention'](normed)
        x = Tensor(x.data + attn_out.data, requires_grad=x.requires_grad)
        
        # Pre-norm SwiGLU FFN + residual
        normed = self._modules['norm2'](x)
        gate = self._modules['silu'](self._modules['gate_proj'](normed))
        up = self._modules['up_proj'](normed)
        ffn_out = self._modules['down_proj'](Tensor(gate.data * up.data, requires_grad=True))
        
        return Tensor(x.data + ffn_out.data, requires_grad=x.requires_grad)


class MSELoss(Module):
    def forward(self, y_pred: Tensor, y_true: Tensor) -> Tensor:
        return ((y_pred - y_true) ** 2).mean()


class CrossEntropyLoss(Module):
    """Cross-Entropy Loss para clasificación."""
    def forward(self, logits: Tensor, targets: Tensor) -> Tensor:
        # Softmax
        exp_logits = np.exp(logits.data - np.max(logits.data, axis=-1, keepdims=True))
        probs = exp_logits / (np.sum(exp_logits, axis=-1, keepdims=True) + 1e-10)
        
        # Negative log-likelihood
        batch_size = logits.data.shape[0]
        target_indices = targets.data.astype(int).flatten()
        log_probs = -np.log(probs[np.arange(batch_size), target_indices] + 1e-10)
        loss = np.mean(log_probs)
        
        return Tensor(np.array(loss, dtype=np.float32), requires_grad=True)
