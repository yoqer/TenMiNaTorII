# Publicar TenMiNaTor en PyPI

## Requisitos previos

```bash
pip install build twine
```

## 1. Verificar que los tests pasan

```bash
cd TenMiNaTor_v2
python -m pytest tests/ -v
# Debe mostrar: 41 passed
```

## 2. Construir los paquetes de distribución

```bash
python -m build
```

Esto genera en `dist/`:
- `tenminator-2.0.0-py3-none-any.whl` — Wheel (instalación rápida)
- `tenminator-2.0.0.tar.gz` — Source distribution

## 3. Verificar el paquete

```bash
twine check dist/*
# Debe mostrar: PASSED
```

## 4. Publicar en TestPyPI primero (recomendado)

```bash
twine upload --repository testpypi dist/*
# URL: https://test.pypi.org/project/tenminator/
```

Probar la instalación desde TestPyPI:
```bash
pip install --index-url https://test.pypi.org/simple/ tenminator
```

## 5. Publicar en PyPI oficial

```bash
twine upload dist/*
# Pedirá tu token de API de PyPI
```

Para obtener el token: https://pypi.org/manage/account/token/

## 6. Verificar la publicación

```bash
pip install tenminator==2.0.0
python -c "import tenminator; print(tenminator.__version__)"
# Debe mostrar: 2.0.0
```

## Actualizar versión

1. Editar `tenminator/__init__.py`: `__version__ = "2.0.1"`
2. Editar `pyproject.toml`: `version = "2.0.1"`
3. Repetir pasos 1-6

## Nombres PyPI del ecosistema yoqer

| Framework | Nombre PyPI | Comando |
|-----------|-------------|---------|
| TenMiNaTor | `tenminator` | `pip install tenminator` |
| TERMINATORI | `terminatori` | `pip install terminatori` |
| TerminaTodo | `terminatodo` | `pip install terminatodo` |
| TERMINATOR | `terminator-yoqer` | `pip install terminator-yoqer` |
| TeMiNaTor | `teminaTor` | `pip install teminaTor` |
