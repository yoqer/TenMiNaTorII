"""Tests completos para el motor de cuantización de TenMiNaTor."""
import sys
import os
import tempfile
import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tenminator.quantization.formats import (
    quantize_q8, quantize_q6, quantize_q5, quantize_q4,
    quantize_q3_turbo, quantize_q2_kivi, quantize_q1_bitnet,
    quantize_nvfp4, quantize_ant4,
    dequantize, QuantizedTensor
)
from tenminator.quantization.engine import Quantizer, QuantConfig
from tenminator.quantization.export import GGUFExporter, ChipExporter, UnikernelExporter


# ═══════════════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════════════

@pytest.fixture
def sample_weights():
    np.random.seed(42)
    return np.random.randn(128, 64).astype(np.float32)

@pytest.fixture
def small_weights():
    np.random.seed(42)
    return np.random.randn(32, 16).astype(np.float32)

@pytest.fixture
def model_state_dict():
    np.random.seed(42)
    return {
        "layer1.weight": np.random.randn(64, 32).astype(np.float32),
        "layer1.bias": np.random.randn(64).astype(np.float32),
        "layer2.weight": np.random.randn(32, 64).astype(np.float32),
        "layer2.bias": np.random.randn(32).astype(np.float32),
        "output.weight": np.random.randn(10, 32).astype(np.float32),
    }


# ═══════════════════════════════════════════════════════════════
# Tests de formatos individuales
# ═══════════════════════════════════════════════════════════════

class TestQ8:
    def test_quantize_shape(self, sample_weights):
        qt = quantize_q8(sample_weights)
        assert qt.bits == 8
        assert qt.format_name == "Q8_0"
        assert qt.shape == sample_weights.shape
    
    def test_dequantize_error(self, sample_weights):
        qt = quantize_q8(sample_weights)
        recon = dequantize(qt)
        assert recon.shape == sample_weights.shape
        mse = np.mean((sample_weights - recon) ** 2)
        assert mse < 0.001  # Q8 debe tener error muy bajo

class TestQ6:
    def test_quantize(self, sample_weights):
        qt = quantize_q6(sample_weights)
        assert qt.bits == 6
        assert qt.format_name == "Q6_K"
    
    def test_dequantize(self, sample_weights):
        qt = quantize_q6(sample_weights)
        recon = dequantize(qt)
        mse = np.mean((sample_weights - recon) ** 2)
        assert mse < 0.01

class TestQ5:
    def test_quantize(self, sample_weights):
        qt = quantize_q5(sample_weights)
        assert qt.bits == 5
        assert qt.format_name == "Q5_K_M"
    
    def test_dequantize(self, sample_weights):
        qt = quantize_q5(sample_weights)
        recon = dequantize(qt)
        mse = np.mean((sample_weights - recon) ** 2)
        assert mse < 0.05

class TestQ4:
    def test_quantize(self, sample_weights):
        qt = quantize_q4(sample_weights)
        assert qt.bits == 4
        assert qt.format_name == "Q4_K_M"
        assert qt.zeros is not None  # Asimétrico
    
    def test_dequantize(self, sample_weights):
        qt = quantize_q4(sample_weights)
        recon = dequantize(qt)
        mse = np.mean((sample_weights - recon) ** 2)
        assert mse < 0.1

class TestQ3TurboQuant:
    def test_quantize(self, sample_weights):
        qt = quantize_q3_turbo(sample_weights)
        assert qt.bits == 3
        assert qt.format_name == "TQ3_0"
        assert qt.rotation is not None  # Hadamard
        assert qt.metadata["method"] == "turboquant"
    
    def test_dequantize(self, sample_weights):
        qt = quantize_q3_turbo(sample_weights)
        recon = dequantize(qt)
        assert recon.shape == sample_weights.shape
        # Q3 tiene más error pero debe ser razonable
        cosine = np.dot(sample_weights.flatten(), recon.flatten()) / (
            np.linalg.norm(sample_weights.flatten()) * np.linalg.norm(recon.flatten()) + 1e-10
        )
        assert cosine > 0.8  # Correlación > 80%
    
    def test_hadamard_rotation(self, small_weights):
        qt = quantize_q3_turbo(small_weights, group_size=16)
        assert qt.rotation.shape[0] == 16
        # Verificar ortogonalidad
        R = qt.rotation
        identity = R @ R.T
        assert np.allclose(identity, np.eye(16), atol=0.01)

class TestQ2KIVI:
    def test_quantize(self, sample_weights):
        qt = quantize_q2_kivi(sample_weights)
        assert qt.bits == 2
        assert qt.format_name == "Q2_KIVI"
        assert qt.metadata["method"] == "kivi_asymmetric"
    
    def test_outlier_preservation(self, sample_weights):
        qt = quantize_q2_kivi(sample_weights)
        assert "outlier_values" in qt.metadata
        assert "outlier_mask" in qt.metadata
    
    def test_dequantize(self, sample_weights):
        qt = quantize_q2_kivi(sample_weights)
        recon = dequantize(qt)
        assert recon.shape == sample_weights.shape

class TestQ1BitNet:
    def test_quantize(self, sample_weights):
        qt = quantize_q1_bitnet(sample_weights)
        assert qt.bits == 1
        assert qt.format_name == "Q1_BitNet"
        assert qt.metadata["method"] == "bitnet_b158"
    
    def test_ternary_values(self, small_weights):
        qt = quantize_q1_bitnet(small_weights)
        recon = dequantize(qt)
        # Valores reconstruidos deben ser múltiplos de gamma
        gamma = qt.scales[0]
        normalized = recon.flatten() / gamma
        unique = np.unique(np.round(normalized))
        assert all(v in [-1, 0, 1] for v in unique)
    
    def test_packing(self, small_weights):
        qt = quantize_q1_bitnet(small_weights)
        # 4 valores por byte → datos deben ser ~4x más pequeños
        n_weights = np.prod(small_weights.shape)
        expected_bytes = (n_weights + 3) // 4
        assert len(qt.data) == expected_bytes

class TestNVFP4:
    def test_quantize(self, sample_weights):
        qt = quantize_nvfp4(sample_weights)
        assert qt.bits == 4
        assert qt.format_name == "NVFP4"
        assert qt.codebook is not None
    
    def test_fp4_values(self, sample_weights):
        qt = quantize_nvfp4(sample_weights)
        # Todos los índices deben estar en [0, 15]
        assert qt.data.max() <= 15
        assert qt.data.min() >= 0
    
    def test_dequantize(self, sample_weights):
        qt = quantize_nvfp4(sample_weights)
        recon = dequantize(qt)
        assert recon.shape == sample_weights.shape

class TestANT4:
    def test_quantize(self, sample_weights):
        qt = quantize_ant4(sample_weights)
        assert qt.bits == 4
        assert qt.format_name == "ANT4"
        assert "type_distribution" in qt.metadata
    
    def test_adaptive_types(self, sample_weights):
        qt = quantize_ant4(sample_weights)
        dist = qt.metadata["type_distribution"]
        # Debe haber al menos un tipo seleccionado
        total = sum(dist.values())
        assert total > 0
    
    def test_dequantize(self, sample_weights):
        qt = quantize_ant4(sample_weights)
        recon = dequantize(qt)
        assert recon.shape == sample_weights.shape


# ═══════════════════════════════════════════════════════════════
# Tests del motor Quantizer
# ═══════════════════════════════════════════════════════════════

class TestQuantizer:
    def test_quantize_model(self, model_state_dict):
        q = Quantizer(QuantConfig(bits=4))
        result = q.quantize_model(model_state_dict)
        assert len(result) == len(model_state_dict)
        assert q.stats["compression_ratio"] > 1
    
    def test_dequantize_model(self, model_state_dict):
        q = Quantizer(QuantConfig(bits=4))
        quantized = q.quantize_model(model_state_dict)
        restored = q.dequantize_model(quantized)
        assert set(restored.keys()) == set(model_state_dict.keys())
    
    def test_measure_error(self, sample_weights):
        q = Quantizer(QuantConfig(bits=4))
        qt = q.quantize_weights(sample_weights)
        error = q.measure_error(sample_weights, qt)
        assert "mse" in error
        assert "cosine_similarity" in error
        assert error["cosine_similarity"] > 0.9
    
    def test_mixed_precision(self, model_state_dict):
        config = QuantConfig(
            bits=3, mixed_precision=True,
            sensitive_layers=["output.weight"],
            sensitive_bits=8
        )
        q = Quantizer(config)
        result = q.quantize_model(model_state_dict)
        assert result["output.weight"].bits == 8
        assert result["layer1.weight"].bits == 3
    
    def test_recommend(self):
        rec = Quantizer.recommend(7, 8)
        assert rec["model_params_b"] == 7
        assert len(rec["formats"]) > 0
        recommended = [r for r in rec["formats"] if r["recommended"]]
        assert len(recommended) >= 1
    
    def test_list_formats(self):
        formats = Quantizer.list_formats()
        assert "Q4_K_M" in formats
        assert "TQ3_0" in formats
        assert "Q1_BitNet" in formats
        assert "NVFP4" in formats
        assert "ANT4" in formats
    
    def test_all_bit_levels(self, small_weights):
        for bits in [1, 2, 3, 4, 5, 6, 8]:
            q = Quantizer(QuantConfig(bits=bits))
            qt = q.quantize_weights(small_weights)
            assert qt.bits == bits
    
    def test_invalid_bits(self):
        with pytest.raises(ValueError):
            QuantConfig(bits=7)


# ═══════════════════════════════════════════════════════════════
# Tests de exportación
# ═══════════════════════════════════════════════════════════════

class TestGGUFExporter:
    def test_export(self, model_state_dict):
        q = Quantizer(QuantConfig(bits=4))
        quantized = q.quantize_model(model_state_dict)
        
        with tempfile.NamedTemporaryFile(suffix=".gguf", delete=False) as f:
            path = f.name
        
        try:
            exporter = GGUFExporter(model_name="test-model")
            result = exporter.export(quantized, path)
            assert os.path.exists(result)
            assert os.path.getsize(result) > 0
            
            # Verificar magic number
            with open(result, "rb") as f:
                import struct
                magic = struct.unpack("<I", f.read(4))[0]
                assert magic == 0x46475547  # "GGUF"
        finally:
            os.unlink(path)

class TestChipExporter:
    def test_export(self, model_state_dict):
        q = Quantizer(QuantConfig(bits=3))
        quantized = q.quantize_model(model_state_dict)
        
        with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
            path = f.name
        
        try:
            exporter = ChipExporter(target="taalas_hc1")
            result = exporter.export(quantized, path)
            assert os.path.exists(result)
            
            # Verificar manifest
            manifest_path = path.replace(".bin", "_manifest.json")
            assert os.path.exists(manifest_path)
            
            import json
            with open(manifest_path) as f:
                manifest = json.load(f)
            assert manifest["target"] == "taalas_hc1"
            assert manifest["total_params"] > 0
        finally:
            os.unlink(path)
            manifest_path = path.replace(".bin", "_manifest.json")
            if os.path.exists(manifest_path):
                os.unlink(manifest_path)
    
    def test_estimate_silicon(self, model_state_dict):
        q = Quantizer(QuantConfig(bits=3))
        quantized = q.quantize_model(model_state_dict)
        
        exporter = ChipExporter()
        estimate = exporter.estimate_silicon_area(quantized)
        assert estimate["total_bits"] > 0
        assert estimate["estimated_area_mm2"] >= 0  # Small models may round to 0

class TestUnikernelExporter:
    def test_export(self, model_state_dict):
        q = Quantizer(QuantConfig(bits=4))
        quantized = q.quantize_model(model_state_dict)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            exporter = UnikernelExporter(runtime="unikraft")
            result = exporter.export(quantized, tmpdir, model_name="test")
            
            assert os.path.exists(os.path.join(tmpdir, "test.tmq"))
            assert os.path.exists(os.path.join(tmpdir, "serve.py"))
            assert os.path.exists(os.path.join(tmpdir, "kraft.yaml"))
            assert os.path.exists(os.path.join(tmpdir, "firecracker.json"))
            assert os.path.exists(os.path.join(tmpdir, "Dockerfile"))
            assert os.path.exists(os.path.join(tmpdir, "deploy.sh"))


# ═══════════════════════════════════════════════════════════════
# Tests de integraciones
# ═══════════════════════════════════════════════════════════════

class TestIntegrations:
    def test_terminatori_bridge_init(self):
        from tenminator.integrations import TerminatoriBridge
        bridge = TerminatoriBridge("http://localhost:8001")
        assert bridge.api_url == "http://localhost:8001"
    
    def test_terminatodo_bridge_init(self):
        from tenminator.integrations import TerminaTodoBridge
        bridge = TerminaTodoBridge("http://localhost:8002")
        assert bridge.api_url == "http://localhost:8002"
    
    def test_unsloth_bridge_format(self):
        from tenminator.integrations import UnslothBridge
        state = {"w": np.random.randn(4, 4).astype(np.float32)}
        # Sin torch, debe fallar con ImportError
        try:
            result = UnslothBridge.to_unsloth_format(state)
        except ImportError:
            pass  # Esperado sin torch
    
    def test_unsloth_finetune_not_installed(self):
        from tenminator.integrations import UnslothBridge
        result = UnslothBridge.finetune("test", "test.json")
        assert result["status"] == "not_available"
        assert "command" in result


# ═══════════════════════════════════════════════════════════════
# Tests de CLI
# ═══════════════════════════════════════════════════════════════

class TestCLI:
    def test_info(self, capsys):
        from tenminator.cli import cmd_info
        cmd_info(None)
        captured = capsys.readouterr()
        assert "TenMiNaTor" in captured.out
        assert "Q4_K_M" in captured.out
    
    def test_recommend(self, capsys):
        from tenminator.cli import cmd_recommend
        
        class Args:
            params = 7
            vram = 8
        
        cmd_recommend(Args())
        captured = capsys.readouterr()
        assert "7" in captured.out
        assert "Q4_K_M" in captured.out


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
